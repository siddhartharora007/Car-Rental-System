<?php
/*For My LocalPC*/
$con=mysqli_connect ("localhost", "root", "") or die ('cannot connect');
mysqli_select_db ($con,'users');
?>



